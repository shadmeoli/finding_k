# Finding_k
A simplified way to find the value of K in a KNN model.


### Installation

```
pip3 install git+https://github.com/shadmeoli/finding_k
```